export const actionsId = {
    logonAction: "Logon",
    refreshAction: "Refresh",
    newAction: "New",
    saveAction: "Save",
    saveAndCloseAction: "SaveAndClose",
    editAction: "SwitchToEditMode",
    fullTextSearch: "FullTextSearch"
};
